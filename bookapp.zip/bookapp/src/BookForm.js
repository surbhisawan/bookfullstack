import {useState} from 'react';
import './BookForm.css';
import axios from 'axios';

function BookForm(props){

    const[book,setbook] = useState({bkid:props.bkid , bkname:props.bkname , bkprice:props.bkprice});
    const [bookarr,setbookarr] = useState([]);
 
    const baseUrl = "http://localhost:8087";

     const getallbooks = () =>{
        axios.get(baseUrl+"/books")
            .then( (response) => {
                setbookarr(response.data);
            }).catch((error) => {
                console.log(error)
            })
     }


     const deleteBook = (b) =>{
        console.log("inside the deletebook method...");
        axios.delete(baseUrl+"/deletebook/"+b.bkid)
          .then((response) =>{
            console.log(response.data);
            setbookarr((book) =>{
                book.filter((e) => e.bkid !== b.bkid)
            }
            ) 
            getallbooks();
          }).catch((error) =>{
            console.log(error);
          })
     }


     const updateBook = (b) =>{
        console.log(b);
        setbook(b);
     }

     const addbook = (e) =>{
        e.preventDefault();
        console.log("inside addbook method...");
        
        let arr = bookarr.filter(e => e.bkid === book.bkid);
        if(arr.length === 0){
            axios.post(baseUrl+"/addbook",book)
              .then( (response) =>{
            console.log("book with id " + book.bkid +" is posted successfully");
            alert("book with id" + book.bkid +" is posted successfully");
            getallbooks();
        } );
        }else{
            axios.put(baseUrl+"/updatebook",book)
              .then((response) =>{
            console.log("book with id " + book.bkid +" is updated successfully");
            alert("book with id" + book.bkid +" is updated successfully");
            getallbooks();
            })
        }

        
     }

    return (
        <>

        <form onSubmit={addbook}>
             <label >Bookid : 
             <input type="number"
                    value={book.bkid}
                    onChange={ (b) => setbook({...book, bkid:b.target.value})}
             /></label><br/>
             <label >Bookname : 
             <input type="text"
                    value={book.bkname}
                    onChange={ (b) => setbook({...book, bkname:b.target.value})}
             /></label><br/>
             <label >Bookprice : 
             <input type="number"
                    value={book.bkprice}
                    onChange={ (b) => setbook({...book, bkprice:b.target.value})}
             /></label><br/>

             <button type='submit'>Add Book</button>
        </form>

        <hr/>

        <button onClick={ () => {getallbooks()}} >GetBooks</button>


        <table id='book'>
            <thead>
              {bookarr!=null &&
                <tr>
                    <th>BookId</th>
                    <th>BookName</th>
                    <th>BookPrice</th>
                 </tr>
              }
            </thead>
            <tbody>
               { bookarr!=null &&
                bookarr.map((b) =>
                    <tr key={b.bkid}>
                      <td>{b.bkid}</td>
                      <td>{b.bkname}</td>
                      <td>{b.bkprice}</td>
                      <td><button onClick={() => deleteBook(b)}>Delete</button></td>
                      <td><button onClick={() => updateBook(b)}>Update</button></td>
                    </tr>
                  )}
            </tbody>
        </table>

        </>
    );
}

export default BookForm;