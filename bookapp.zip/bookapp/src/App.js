import BookForm from "./BookForm";
import './App.css';

function App() {
  return (
    <div className="App">
        <BookForm/>
    </div>
  );
}

export default App;
